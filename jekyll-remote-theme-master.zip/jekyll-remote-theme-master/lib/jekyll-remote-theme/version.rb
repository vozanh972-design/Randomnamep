# frozen_string_literal: true

module Jekyll
  module RemoteTheme
    VERSION = "0.4.3"
  end
end
